import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './auth/auth.module';
import { UserModule } from './user/user.module';
import { APP_GUARD } from '@nestjs/core';
import { AuthGuard } from './auth/auth.guard';
import { SpecModule } from './spec/spec.module';
import { ProjectModule } from './project/project.module';
import { NotificationsModule } from './notifications/notifications.module';


@Module({
  imports: [AuthModule, UserModule, SpecModule, ProjectModule, NotificationsModule,],
  controllers: [AppController],
  providers: [AppService,
  ],
})
export class AppModule { }
