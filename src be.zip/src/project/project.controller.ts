import { Body, Controller, Post, Get, UseGuards, Req, Param } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { ProjectService } from './project.service';
import { AuthGuard } from 'src/auth/auth.guard';
import { RegisterTopicDto } from 'src/dto/RegisterTopicDto';

@Controller('project')
@ApiTags('project')
export class ProjectController {
    constructor(private readonly projectService: ProjectService) { }

    @Post('registerproject')
    @ApiBearerAuth()
    @UseGuards(AuthGuard)
    async registerProject(@Req() req: Request, @Body() prDto: RegisterTopicDto) {
        const user = req['user'];

        return this.projectService.registerProject(user, prDto);
    }

    @Get('getproject')
    @ApiBearerAuth()
    @UseGuards(AuthGuard)
    async getProject(@Req() req) {
        return this.projectService.getProject(req.user.TaiKhoan)
    }

    @Get('/:id')
    @ApiBearerAuth()
    @UseGuards(AuthGuard)
    getProjectById(@Param('id') id: string) {
        return this.projectService.getProjectById(id);
    }

    @Get('member/:id')
    @ApiBearerAuth()
    @UseGuards(AuthGuard)
    getMemberById(@Param('id') id: string) {
        return this.projectService.getMemberById(id);
    }
}