import { Module } from '@nestjs/common';
import { UserController } from './user.controller';
import { UserService } from './user.service';
import { NguoiDung } from 'src/entity/user.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PhanLoai } from 'src/entity/speclist.entity';
import { ChuyenNganh } from 'src/entity/spec.entity';
import { NguoiHD } from 'src/entity/teacher.entity';
import { DeTai } from 'src/entity/project.entity';
import { ThanhVienDT } from 'src/entity/pjmem.entity';
import { ThongBao } from 'src/entity/notification.entity';
import { AuthModule } from 'src/auth/auth.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mssql',
      host: 'localhost',
      port: 1433,
      username: 'hungmochi211',
      password: 'Hung',
      database: 'QuanLyDeTai',
      entities: [NguoiDung, ChuyenNganh, PhanLoai, NguoiHD, DeTai, ThanhVienDT,ThongBao],
      synchronize: false,
      options: {
        encrypt: false,
        trustServerCertificate: true,
      }
    }),
    TypeOrmModule.forFeature([NguoiDung]),
  ],
  controllers: [UserController],
  providers: [UserService],
  exports: [UserService],
})
export class UserModule { }